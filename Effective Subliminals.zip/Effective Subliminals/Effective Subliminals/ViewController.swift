//
//  ViewController.swift
//  Effective Subliminals
//
//  Created by Suchindra Chandrahas on 10/08/21.
//

import Cocoa

class ViewController: NSViewController {

    var buttonHidden = 0
    override func viewDidLoad() {
        super.viewDidLoad()

        self.view.wantsLayer = true
        self.view.window?.hasShadow = false
        
        var mouseLocation: NSPoint { NSEvent.mouseLocation }
        let window = NSApplication.shared.windows.first
        var location: NSPoint { window!.mouseLocationOutsideOfEventStream }

        NSEvent.addLocalMonitorForEvents(matching: [.rightMouseDown]) {
            print("Toggling Read Messages button")
            if self.buttonHidden == 0 {
                self.readMessagesButton.isHidden = true
                self.buttonHidden = 1
            } else {
                self.readMessagesButton.isHidden = false
                self.buttonHidden = 0
            }
            return $0
        }

        NSEvent.addLocalMonitorForEvents(matching: [.keyDown], handler: keyDown)

        let msg = String("")
        self.setLabel(msg: msg)
        self.readMessagesButton.isHidden = false
        
    }
    
    @IBOutlet weak var subLabel: NSTextField!
    
    @IBOutlet weak var readMessagesButton: NSButton!
    
    @IBAction func readMessages(_ sender: Any) {
        
        let subFile = ".sub_msgs.txt"
        var content = ""
        
        let homeDirURL = FileManager.default.homeDirectoryForCurrentUser
        
        let fileURL = homeDirURL.appendingPathComponent(subFile)
     
        do {
            content = try String(contentsOf: fileURL, encoding: .utf8)
            content = content.replacingOccurrences(of: "\n", with: "")
    
            setLabel(msg: content)
        } catch {/* error handling here */}
        
        self.readMessagesButton.isHidden = true
        
    }
    
    func keyDown(event: NSEvent) -> NSEvent
    {
        if event.keyCode == 24 {
            let curFontSize = self.subLabel.font?.pointSize ?? 12
            self.subLabel.font = self.subLabel.font?.withSize(curFontSize + 1)
        } else if event.keyCode == 27 {
            let curFontSize = self.subLabel.font?.pointSize ?? 12
            self.subLabel.font = self.subLabel.font?.withSize(curFontSize - 1)
        } else if event.keyCode == 34 {
            self.subLabel.alphaValue = self.subLabel.alphaValue - 5
        } else if event.keyCode == 2 {
            self.subLabel.alphaValue = self.subLabel.alphaValue + 5
        } else {
            print("Unknown key")
        }
        return event
    }
    func setLabel(msg: String) {
        
        let subMsg = String(repeating: msg + "    ", count: 100000)
        subLabel.stringValue = subMsg
        let window = NSApplication.shared.windows.first
        window?.ignoresMouseEvents = true
    
    }
    override var representedObject: Any? {
    didSet {
    // Update the window
    }
}



}

